import { PuppeteerCrawler } from 'crawlee';

export const crawler = new PuppeteerCrawler({
    async requestHandler({ page, log, pushData }) {
        log.info('Abrindo a página do grupo...');
        await page.waitForSelector('body');

        const posts = await page.evaluate(() => {
            const postElements = document.querySelectorAll('[role="article"]');
            const extracted = [];

            postElements.forEach(post => {
                const name = post.querySelector('h2 span span')?.innerText || '';
                const content = post.innerText || '';
                const date = post.querySelector('abbr')?.innerText || '';
                if (name.includes('Claudio Braga de Oliveira')) {
                    extracted.push({ name, content, date });
                }
            });

            return extracted;
        });

        await pushData(posts);
    },
    preNavigationHooks: [
        async ({ page, log }) => {
            log.info('Logue no Facebook com sua conta...');
            await page.goto('https://www.facebook.com/login');
            await page.waitForNavigation({ waitUntil: 'networkidle0' });
            await page.goto('https://www.facebook.com/groups/345297419948376');
            await page.waitForSelector('[role="feed"]', { timeout: 60000 });
        }
    ],
    headless: false,
    useSessionPool: true,
    maxRequestsPerCrawl: 1,
});

export default async function main() {
    await crawler.run([
        'https://www.facebook.com/groups/345297419948376'
    ]);
}
